const API_URL = process.env.EXPO_PUBLIC_RUNPOD_API_URL as string;;
const API_KEY = process.env.EXPO_PUBLIC_RUNPOD_API_KEY as string;; 

export { API_URL, API_KEY };